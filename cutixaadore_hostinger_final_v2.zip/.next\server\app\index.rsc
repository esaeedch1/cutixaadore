1:"$Sreact.fragment"
2:I[59919,["/_next/static/chunks/36181f50d53b6c25.js"],"ThemeProvider"]
3:I[13865,["/_next/static/chunks/36181f50d53b6c25.js"],"LanguageProvider"]
4:I[39756,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"default"]
5:I[37457,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"default"]
6:I[22016,["/_next/static/chunks/36181f50d53b6c25.js","/_next/static/chunks/7c92e96509cd355e.js"],""]
7:I[99220,["/_next/static/chunks/36181f50d53b6c25.js"],"FloatingWidgets"]
8:I[47257,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"ClientPageRoot"]
9:I[52683,["/_next/static/chunks/36181f50d53b6c25.js","/_next/static/chunks/df25c783702f6f82.js"],"default"]
c:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"OutletBoundary"]
d:"$Sreact.suspense"
f:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"ViewportBoundary"]
11:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"MetadataBoundary"]
13:I[68027,[],"default"]
:HL["/_next/static/chunks/ee8e8860814cd148.css","style"]
:HL["/_next/static/chunks/46ae2639be179c45.css","style"]
0:{"P":null,"b":"KvbVhUP7-EclopNKDIofI","c":["",""],"q":"","i":false,"f":[[["",{"children":["__PAGE__",{}]},"$undefined","$undefined",true],[["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/ee8e8860814cd148.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/36181f50d53b6c25.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","children":["$","body",null,{"children":["$","$L2",null,{"children":["$","$L3",null,{"children":[["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"style":{"display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center","height":"100vh","textAlign":"center","backgroundColor":"var(--background)","color":"var(--foreground)"},"children":[["$","h1",null,{"className":"brand-name","style":{"fontSize":"4rem","marginBottom":"1rem"},"children":"Coming Soon....."}],["$","p",null,{"style":{"opacity":0.6,"marginBottom":"2rem"},"children":"We are working hard to bring you the best skincare experience."}],["$","$L6",null,{"href":"/","style":{"padding":"0.8rem 2rem","border":"1px solid var(--gold-matte)","color":"var(--gold-matte)","borderRadius":"50px","textDecoration":"none","transition":"var(--transition-smooth)"},"children":"Return Home"}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}],["$","$L7",null,{}]]}]}]}]}]]}],{"children":[["$","$1","c",{"children":[["$","$L8",null,{"Component":"$9","serverProvidedParams":{"searchParams":{},"params":{},"promises":["$@a","$@b"]}}],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/46ae2639be179c45.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/df25c783702f6f82.js","async":true,"nonce":"$undefined"}]],["$","$Lc",null,{"children":["$","$d",null,{"name":"Next.MetadataOutlet","children":"$@e"}]}]]}],{},null,false,false]},null,false,false],["$","$1","h",{"children":[null,["$","$Lf",null,{"children":"$L10"}],["$","div",null,{"hidden":true,"children":["$","$L11",null,{"children":["$","$d",null,{"name":"Next.Metadata","children":"$L12"}]}]}],null]}],false]],"m":"$undefined","G":["$13",[]],"S":true}
a:{}
b:"$0:f:0:1:1:children:0:props:children:0:props:serverProvidedParams:params"
10:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
14:I[27201,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/a2dfb6fc5208ab9b.js"],"IconMark"]
e:null
12:[["$","title","0",{"children":"CutiXa Adore | Love Your Skin"}],["$","meta","1",{"name":"description","content":"Premium skin-care eCommerce experience. Love Your Skin with CutiXa Adore."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0b3bf435.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L14","3",{}]]
