var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/users/route.js")
R.c("server/chunks/[root-of-the-server]__983f4e35._.js")
R.c("server/chunks/[root-of-the-server]__289d1ec0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_users_route_actions_4b9121e3.js")
R.m(75468)
module.exports=R.m(75468).exports
