var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/invoices/route.js")
R.c("server/chunks/[root-of-the-server]__fd79edc5._.js")
R.c("server/chunks/[root-of-the-server]__289d1ec0._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_invoices_route_actions_51333992.js")
R.m(57736)
module.exports=R.m(57736).exports
