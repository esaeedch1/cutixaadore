:HL["/_next/static/chunks/ee8e8860814cd148.css","style"]
:HL["/_next/static/chunks/0843ca6e7f0a0bd4.css","style"]
0:{"buildId":"G6J1qRozGucpFhmH2ehKA","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"checkout","paramType":null,"paramKey":"checkout","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
