# 🚀 CutiXa Adore — Hostinger Deployment Guide

This guide provides the exact steps to migrate your local project from `http://192.168.56.1:3000/` to your Hostinger live server.

---

## 🏗️ Step 1: Preparing Your Database (SQL)

Your website requires a persistent database for real-time synchronization between Admin and Customers.

1.  Log in to your **Hostinger hPanel**.
2.  Navigate to **Databases** > **MySQL Databases**.
3.  Create a new database (e.g., `u123_cutixa`) and a user with a strong password.
4.  Open **phpMyAdmin** for your new database.
5.  Click the **Import** tab.
6.  Upload the file: `d:\Development\antigravity development\Web Projects\cutixaadore\database\schema.sql`.
7.  Click **Go** to create all tables (Users, Products, Orders, Invoices, etc.).

---

## 🏗️ Step 2: Preparing the Files (Build)

You **cannot** just upload the source code. You must compile it first.

1.  Open your terminal in the project root.
2.  Run the production build:
    ```bash
    npm run build
    ```
3.  This generates a `.next` folder. This is the "Engine" of your site.
4.  **Zip the following folders/files** (important for Hostinger):
    *   `.next/` (The build output)
    *   `public/` (Images and icons)
    *   `package.json` (Dependency list)
    *   `node_modules/` (If your plan allows direct upload, otherwise Hostinger can run `npm install`)
    *   `.env` (Updated for production)

> [!IMPORTANT]
> Change the `.env` file for production before zipping:
> ```env
> NEXT_PUBLIC_BASE_URL=https://your-domain.com
> NEXT_PUBLIC_API_URL=https://your-domain.com/api
> NODE_ENV=production
> ```

---

## 🏗️ Step 3: Uploading to Hostinger

### Option A: Shared Hosting (Cheaper Plan)
If you are on a Shared Hosting plan that **doesn't** support Node.js directly:
1.  Add `output: 'export'` to your `next.config.ts` file.
2.  Run `npm run build`.
3.  Upload the contents of the generated `out/` folder to `public_html/`.

### Option B: Node.js Hosting (Recommended)
1.  Go to **Node.js** in your Hostinger dashboard.
2.  Upload your `.zip` file into the file manager and **Extract** it.
3.  Use the **Node.js Configuration**:
    *   **Node.js version**: 20 or 22
    *   **Application root**: `/` (or your folder name)
    *   **Start command**: `npm start`
4.  Click **Start/Node.js Startup**.

---

## 🏗️ Step 4: Critical Notice on "Synchronization"

> [!WARNING]
> Your current code uses **`localStorage`** to store products and orders.
> 
> *   **Localhost**: Since you were the only one using it, it seemed "synced."
> *   **Production**: Browsers **do not share** `localStorage`. If you add a product as Admin, a Customer on another computer will **not** see it!
> 
> **To fix this on Hostinger:**
> You must implement Next.js **API Routes** (server-side) to bridge the gap between your frontend and the MySQL database I provided in Step 1.

### Next Steps for Full Real-Time Sync:
1.  **Backend Migration**: Replace `localStorage.getItem` with `fetch('/api/products')`.
2.  **API Implementation**: Create a backend route to talk to your MySQL database.

---

### Need help implementing the real-time MySQL API?
Just ask me to "**Convert LocalStorage to MySQL API**" and I will implement the server-side logic for you!
