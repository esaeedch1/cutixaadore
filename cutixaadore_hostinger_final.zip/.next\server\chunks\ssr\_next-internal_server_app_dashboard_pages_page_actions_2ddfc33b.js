module.exports=[32623,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_pages_page_actions_2ddfc33b.js.map