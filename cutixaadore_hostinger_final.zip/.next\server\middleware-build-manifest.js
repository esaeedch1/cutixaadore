globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/d59f830a2b8e768c.js",
    "static/chunks/fc8b4c86c7b238eb.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/d5fe3fa7247c5aba.js",
    "static/chunks/82abf2d65f5428ae.js",
    "static/chunks/turbopack-a7902e52f302b3c7.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];