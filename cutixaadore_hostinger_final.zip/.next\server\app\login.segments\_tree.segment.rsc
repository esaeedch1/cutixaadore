:HL["/_next/static/chunks/ee8e8860814cd148.css","style"]
:HL["/_next/static/chunks/f38ff81abe8877cf.css","style"]
0:{"buildId":"G6J1qRozGucpFhmH2ehKA","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"login","paramType":null,"paramKey":"login","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
