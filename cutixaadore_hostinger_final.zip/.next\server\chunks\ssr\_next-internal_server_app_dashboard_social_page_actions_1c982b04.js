module.exports=[96427,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_social_page_actions_1c982b04.js.map